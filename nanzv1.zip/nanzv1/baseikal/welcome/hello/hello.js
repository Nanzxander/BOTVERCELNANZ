const hello =  ` HELLO MEK`
exports.hello = hello