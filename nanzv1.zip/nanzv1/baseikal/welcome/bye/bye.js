const bye =  ` BYE MEK`
exports.bye = bye