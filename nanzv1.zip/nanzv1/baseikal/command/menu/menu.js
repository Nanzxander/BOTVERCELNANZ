const help =  ` 
° Owner  : The Nanz Xander
° Version : 99999
° Baileys : 4.4.0
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱
 ❍ VIP_MENU ❍
┏━━⊱
┣✪➠ Bugmode
┣✪➠ Store
┣✪➠ Belajarkita
┗━━⊱
❍ TUTORIAL BUG ❍
┏━━⊱
┣✪➠ Tutorial1
┣✪➠ Tutorial2
┗━━⊱
❍ MENU_MODS ❍
┏━━⊱
┣✪➠ Tutorial1
┣✪➠ Togif
┣✪➠ Tutorial2
┣✪➠ Afk
┣✪➠ P
┣✪➠ Restart
┣✪➠ Owner
┣✪➠ Verif 62xxx
┣✪➠ User add 62xx
┣✪➠ User del 62xxx
┣✪➠ Setcmd [ reply sticker ]
┣✪➠ Delcmd [ reply sticker ]
┗━━⊱
❍ MENU_GROUP ❍
┏━━⊱
┣✪➠ Antilink on / off
┣✪➠ Welcome on / off
┣✪➠ Detectadmin on / off
┣✪➠ Kick 628xxx
┣✪➠ Add 628xxx
┣✪➠ Promote 628xx
┣✪➠ Demote 628xx
┗━━⊱
📍 𝐍𝐎𝐓𝐄 
THANKS TO HW MODS WA
contact me 
wa.me/6289643559747
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱
© 𝗡𝗔𝗡𝗭`
exports.menu = help